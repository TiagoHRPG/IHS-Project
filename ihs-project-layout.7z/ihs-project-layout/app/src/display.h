#ifndef __DISPLAY_H__
#define __DISPLAY_H__

#define HEX_0 0xFFFFFFC0
#define HEX_1 0xFFFFFFF9
#define HEX_2 0xFFFFFFA4
#define HEX_3 0xFFFFFFB0
#define HEX_4 0xFFFFFF99
#define HEX_5 0xFFFFFF92
#define HEX_6 0xFFFFFF82
#define HEX_7 0xFFFFFFF8
#define HEX_8 0xFFFFFF80
#define HEX_9 0xFFFFFF90
#define HEX_A 0xFFFFFF88
#define HEX_B 0xFFFFFF83
#define HEX_C 0xFFFFFFC6
#define HEX_D 0xFFFFFFA1
#define HEX_E 0xFFFFFF86
#define HEX_F 0xFFFFFF8E

#endif /* __DISPLAY_H__ */
