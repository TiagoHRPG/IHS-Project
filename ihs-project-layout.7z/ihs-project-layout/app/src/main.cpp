#include <stdio.h>	/* printf */
#include <stdlib.h>	/* malloc, atoi, rand... */
#include <string.h>	/* memcpy, strlen... */
#include <stdint.h>	/* uints types */
#include <sys/types.h>	/* size_t ,ssize_t, off_t... */
#include <unistd.h>	/* close() read() write() */
#include <fcntl.h>	/* open() */
#include <sys/ioctl.h>	/* ioctl() */
#include <errno.h>	/* error codes */

#include <SFML/Graphics.hpp>

#include "ioctl_cmds.h"

int main(int argc, char** argv)
{
	int fd, retval, screen = 1;

	if (argc < 2) {
		printf("Syntax: %s <device file path>\n", argv[0]);
		return -EINVAL;
	}

	if ((fd = open(argv[1], O_RDWR)) < 0) {
		fprintf(stderr, "Error opening file %s\n", argv[1]);
		return -EBUSY;
	}

	unsigned int data = 0x40404079;
	unsigned int button = 0b0;
	
	sf::RenderWindow window(sf::VideoMode(600, 600), "Project IHS");
	window.setFramerateLimit(12);

	sf::RectangleShape shape(sf::Vector2f(120.f, 50.f));
	shape.setFillColor(sf::Color::Green);

	while(window.isOpen()){
		sf::Event event;
		
		while(window.pollEvent(event)){
			if(event.type == sf::Event::Closed)
				window.close();
		}

		if(screen == 1) {
			// Reading from button
			ioctl(fd, RD_PBUTTONS);
			read(fd, &button, 1);
			
			// Menu
			printf("qlqr coisa");
			window.draw(shape);
			window.display();

			if(button == 0b1110) {
				window.clear(sf::Color::Green);
				screen = 2;

				data = 0b01;
				ioctl(fd, WR_RED_LEDS);
				write(fd, &data, sizeof(data));
			}
		}
	}

	

	// ioctl(fd, WR_R_DISPLAY);
	// retval = write(fd, &data, sizeof(data));
	// printf("wrote %d bytes\n", retval);
	
	// ioctl(fd, WR_L_DISPLAY);
	// retval = write(fd, &data, sizeof(data));
	// printf("wrote %d bytes\n", retval);
	
	// ioctl(fd, RD_PBUTTONS);
	// read(fd, &data, 1);
	// printf("new data: 0x%X\n", data);
	
	close(fd);
	return 0;
}
